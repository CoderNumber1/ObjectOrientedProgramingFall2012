public interface MoveDecorator extends Move {
    
}
